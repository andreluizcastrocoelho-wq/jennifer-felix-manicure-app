/**
 * Configurações de ambiente do aplicativo
 */

export const ENV = {
  // URL base da API backend
  API_URL: 'https://3000-iiuwhkeus1aqu47euup1f-38bb7a06.us2.manus.computer',
  
  // Credenciais de admin (para desenvolvimento)
  ADMIN_EMAIL: 'boladosakua93@gmail.com',
  ADMIN_PASSWORD: 'Neoqeav2020!',
  
  // Configurações de notificações
  EXPO_PROJECT_ID: 'jennifer-felix-manicure',
  
  // Timeouts
  REQUEST_TIMEOUT: 10000,
  
  // Ambiente
  ENVIRONMENT: process.env.NODE_ENV || 'development',
  
  // Debug
  DEBUG: process.env.NODE_ENV !== 'production',
};

export default ENV;
