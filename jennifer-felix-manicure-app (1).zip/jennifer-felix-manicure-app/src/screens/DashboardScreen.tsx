import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  RefreshControl,
} from 'react-native';
import {
  listAppointments,
  updateAppointmentStatus,
  deleteAppointment,
} from '../services/api';

interface Appointment {
  id: number;
  nomeCliente: string;
  telefone: string;
  data: string;
  horario: string;
  servico: string;
  observacoes?: string;
  status: 'pendente' | 'confirmado' | 'cancelado';
}

export const DashboardScreen: React.FC = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filterStatus, setFilterStatus] = useState<'all' | 'pendente' | 'confirmado' | 'cancelado'>('all');
  const [filterDate, setFilterDate] = useState('');

  useEffect(() => {
    loadAppointments();
  }, [filterStatus, filterDate]);

  const loadAppointments = async () => {
    try {
      setIsLoading(true);

      const filters: any = {};
      if (filterDate) filters.data = filterDate;
      if (filterStatus !== 'all') filters.status = filterStatus;

      const data = await listAppointments(filters);
      setAppointments(Array.isArray(data) ? data : []);
    } catch (error: any) {
      console.error('Erro ao carregar agendamentos:', error);
      Alert.alert('Erro', error.message || 'Falha ao carregar agendamentos');
    } finally {
      setIsLoading(false);
      setRefreshing(false);
    }
  };

  const handleStatusChange = async (appointmentId: number, newStatus: string) => {
    try {
      await updateAppointmentStatus(appointmentId, newStatus as any);
      Alert.alert('Sucesso', 'Status atualizado com sucesso');
      loadAppointments();
    } catch (error: any) {
      console.error('Erro ao atualizar status:', error);
      Alert.alert('Erro', error.message || 'Falha ao atualizar status');
    }
  };

  const handleDelete = async (appointmentId: number) => {
    Alert.alert('Confirmar', 'Deseja deletar este agendamento?', [
      { text: 'Cancelar', onPress: () => {} },
      {
        text: 'Deletar',
        onPress: async () => {
          try {
            await deleteAppointment(appointmentId);
            Alert.alert('Sucesso', 'Agendamento deletado');
            loadAppointments();
          } catch (error: any) {
            console.error('Erro ao deletar:', error);
            Alert.alert('Erro', error.message || 'Falha ao deletar agendamento');
          }
        },
      },
    ]);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmado':
        return '#10b981';
      case 'pendente':
        return '#f59e0b';
      case 'cancelado':
        return '#ef4444';
      default:
        return '#6b7280';
    }
  };

  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('pt-BR');
    } catch {
      return dateString;
    }
  };

  const renderAppointment = ({ item }: { item: Appointment }) => (
    <View style={styles.appointmentCard}>
      <View style={styles.cardHeader}>
        <Text style={styles.clientName}>{item.nomeCliente}</Text>
        <View
          style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) }]}
        >
          <Text style={styles.statusText}>{item.status}</Text>
        </View>
      </View>

      <View style={styles.cardContent}>
        <Text style={styles.detail}>
          📅 {formatDate(item.data)} às {item.horario}
        </Text>
        <Text style={styles.detail}>💅 {item.servico}</Text>
        <Text style={styles.detail}>📱 {item.telefone}</Text>
        {item.observacoes && (
          <Text style={styles.detail}>📝 {item.observacoes}</Text>
        )}
      </View>

      <View style={styles.cardActions}>
        {item.status !== 'confirmado' && (
          <TouchableOpacity
            style={[styles.actionButton, styles.confirmButton]}
            onPress={() => handleStatusChange(item.id, 'confirmado')}
          >
            <Text style={styles.actionButtonText}>Confirmar</Text>
          </TouchableOpacity>
        )}
        {item.status !== 'cancelado' && (
          <TouchableOpacity
            style={[styles.actionButton, styles.cancelButton]}
            onPress={() => handleStatusChange(item.id, 'cancelado')}
          >
            <Text style={styles.actionButtonText}>Cancelar</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity
          style={[styles.actionButton, styles.deleteButton]}
          onPress={() => handleDelete(item.id)}
        >
          <Text style={styles.actionButtonText}>Deletar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  if (isLoading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#ec4899" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Filtros */}
      <View style={styles.filterContainer}>
        <Text style={styles.filterLabel}>Filtrar por Status:</Text>
        <View style={styles.filterButtons}>
          {(['all', 'pendente', 'confirmado', 'cancelado'] as const).map((status) => (
            <TouchableOpacity
              key={status}
              style={[
                styles.filterButton,
                filterStatus === status && styles.filterButtonActive,
              ]}
              onPress={() => setFilterStatus(status)}
            >
              <Text
                style={[
                  styles.filterButtonText,
                  filterStatus === status && styles.filterButtonTextActive,
                ]}
              >
                {status === 'all' ? 'Todos' : status}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Lista de Agendamentos */}
      <FlatList
        data={appointments}
        renderItem={renderAppointment}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => {
              setRefreshing(true);
              loadAppointments();
            }}
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>Nenhum agendamento encontrado</Text>
          </View>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#faf5f0',
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  filterContainer: {
    padding: 15,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#f3e8e8',
  },
  filterLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 10,
  },
  filterButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  filterButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: '#fce7f3',
    backgroundColor: '#fff',
  },
  filterButtonActive: {
    backgroundColor: '#ec4899',
    borderColor: '#ec4899',
  },
  filterButtonText: {
    fontSize: 12,
    color: '#6b7280',
    fontWeight: '500',
  },
  filterButtonTextActive: {
    color: '#fff',
  },
  listContent: {
    padding: 15,
  },
  appointmentCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    borderLeftWidth: 4,
    borderLeftColor: '#ec4899',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  clientName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1f2937',
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  cardContent: {
    marginBottom: 12,
  },
  detail: {
    fontSize: 13,
    color: '#4b5563',
    marginBottom: 6,
    lineHeight: 18,
  },
  cardActions: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  actionButton: {
    flex: 1,
    minWidth: '30%',
    paddingVertical: 8,
    borderRadius: 6,
    alignItems: 'center',
  },
  confirmButton: {
    backgroundColor: '#10b981',
  },
  cancelButton: {
    backgroundColor: '#f59e0b',
  },
  deleteButton: {
    backgroundColor: '#ef4444',
  },
  actionButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 50,
  },
  emptyText: {
    fontSize: 16,
    color: '#9ca3af',
  },
});
