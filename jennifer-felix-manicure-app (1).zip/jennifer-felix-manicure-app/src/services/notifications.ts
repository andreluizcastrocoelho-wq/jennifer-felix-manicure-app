import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';

// Configurar handler de notificações recebidas
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

export const registerForPushNotifications = async () => {
  if (!Device.isDevice) {
    console.log('Notificações push apenas funcionam em dispositivos reais');
    return null;
  }

  try {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      console.log('Permissão para notificações não concedida');
      return null;
    }

    const token = await Notifications.getExpoPushTokenAsync({
      projectId: 'jennifer-felix-manicure',
    });

    return token.data;
  } catch (error) {
    console.error('Erro ao registrar para notificações:', error);
    return null;
  }
};

export const subscribeToNotifications = () => {
  const subscription = Notifications.addNotificationReceivedListener((notification) => {
    console.log('Notificação recebida:', notification);
  });

  return subscription;
};

export const sendLocalNotification = async (title: string, body: string) => {
  await Notifications.scheduleNotificationAsync({
    content: {
      title,
      body,
      sound: true,
      badge: 1,
    },
    trigger: { seconds: 1 },
  });
};
