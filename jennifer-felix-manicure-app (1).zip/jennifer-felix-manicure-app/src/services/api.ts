import axios, { AxiosInstance } from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ENV } from '../config/env';

// Criar instância do axios
const api: AxiosInstance = axios.create({
  baseURL: ENV.API_URL,
  timeout: ENV.REQUEST_TIMEOUT,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor para adicionar token de autenticação
api.interceptors.request.use(
  async (config) => {
    try {
      const token = await AsyncStorage.getItem('adminToken');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    } catch (error) {
      console.error('Erro ao obter token:', error);
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Interceptor para tratamento de erros
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      // Token expirado ou inválido
      await AsyncStorage.removeItem('adminToken');
      await AsyncStorage.removeItem('adminEmail');
      // Redirecionar para login seria feito no componente
    }
    return Promise.reject(error);
  }
);

/**
 * Fazer chamada tRPC para o backend
 */
export const callTRPC = async <T = any>(
  procedure: string,
  input?: any
): Promise<T> => {
  try {
    const response = await api.post(`/api/trpc/${procedure}`, input || {});
    
    // Extrair dados da resposta tRPC
    if (response.data?.result?.data) {
      return response.data.result.data;
    }
    
    return response.data;
  } catch (error: any) {
    console.error(`Erro ao chamar ${procedure}:`, error);
    throw error;
  }
};

/**
 * Listar agendamentos
 */
export const listAppointments = async (filters?: {
  data?: string;
  status?: 'pendente' | 'confirmado' | 'cancelado';
}) => {
  return callTRPC('appointments.list', filters);
};

/**
 * Atualizar status de agendamento
 */
export const updateAppointmentStatus = async (
  id: number,
  status: 'pendente' | 'confirmado' | 'cancelado'
) => {
  return callTRPC('appointments.updateStatus', { id, status });
};

/**
 * Deletar agendamento
 */
export const deleteAppointment = async (id: number) => {
  return callTRPC('appointments.delete', id);
};

export default api;
