import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { ENV } from '../config/env';

interface AuthContextType {
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  user: { email: string } | null;
  error: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState<{ email: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Verificar se há token salvo ao iniciar
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token = await AsyncStorage.getItem('adminToken');
        const email = await AsyncStorage.getItem('adminEmail');
        if (token && email) {
          setIsAuthenticated(true);
          setUser({ email });
        }
      } catch (err) {
        console.error('Erro ao verificar autenticação:', err);
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      setIsLoading(true);
      setError(null);

      // Validar credenciais localmente (para admin)
      // Em produção, isso seria uma chamada ao backend
      if (email === ENV.ADMIN_EMAIL && password === ENV.ADMIN_PASSWORD) {
        // Gerar token seguro
        const token = `admin-token-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        
        // Salvar token e email
        await AsyncStorage.setItem('adminToken', token);
        await AsyncStorage.setItem('adminEmail', email);
        
        // Atualizar estado
        setIsAuthenticated(true);
        setUser({ email });
        
        console.log('Login bem-sucedido para:', email);
      } else {
        throw new Error('Email ou senha inválidos');
      }
    } catch (err: any) {
      const errorMessage = err.message || 'Erro ao fazer login';
      setError(errorMessage);
      console.error('Erro de login:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      setIsLoading(true);
      
      // Remover dados locais
      await AsyncStorage.removeItem('adminToken');
      await AsyncStorage.removeItem('adminEmail');
      
      // Atualizar estado
      setIsAuthenticated(false);
      setUser(null);
      setError(null);
      
      console.log('Logout bem-sucedido');
    } catch (err) {
      console.error('Erro ao fazer logout:', err);
      setError('Erro ao fazer logout');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, isLoading, login, logout, user, error }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de AuthProvider');
  }
  return context;
};
