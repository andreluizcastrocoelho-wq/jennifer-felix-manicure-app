# Guia de Publicação - Jennifer Félix Manicure App

Este documento descreve como publicar o aplicativo mobile em iOS e Android.

## 📋 Pré-requisitos

### Para iOS
- Mac com Xcode instalado
- Apple Developer Account ($99/ano)
- Certificado de distribuição
- Provisioning Profile

### Para Android
- Android Studio instalado
- Google Play Developer Account ($25 único)
- Keystore para assinatura

## 🚀 Publicação com Expo

### 1. Criar Conta Expo

```bash
npm install -g expo-cli
expo login
# Ou criar em https://expo.dev
```

### 2. Preparar para Build

```bash
cd /home/ubuntu/jennifer-felix-manicure-app

# Instalar dependências
npm install

# Verificar app.json está correto
cat app.json
```

### 3. Build para Android

```bash
# Gerar APK (para testes)
expo build:android -t apk

# Gerar AAB (para Google Play)
expo build:android -t app-bundle
```

### 4. Build para iOS

```bash
# Gerar IPA
expo build:ios -t archive

# Ou para simulador
expo build:ios -t simulator
```

### 5. Monitorar Build

```bash
# Ver status do build
expo build:status

# Fazer download quando pronto
expo download:build --id <build-id>
```

## 📱 Publicação na Google Play

### Passo 1: Preparar Conta Google Play

1. Acesse [Google Play Console](https://play.google.com/console)
2. Crie um novo aplicativo
3. Preencha informações básicas:
   - Nome: Jennifer Félix Manicure
   - Descrição
   - Categoria: Estilo de vida
   - Conteúdo: Aplicativo administrativo

### Passo 2: Upload do AAB

1. Vá para "Release" → "Production"
2. Clique "Create new release"
3. Faça upload do arquivo `.aab`
4. Preencha notas de release
5. Revise e publique

### Passo 3: Informações da Loja

- **Título**: Jennifer Félix Manicure
- **Descrição Curta**: Gerencie agendamentos de manicure
- **Descrição Completa**: Aplicativo administrativo para gerenciar agendamentos, receber notificações push e confirmar serviços.
- **Categoria**: Estilo de vida
- **Classificação**: Livre

## 🍎 Publicação na App Store

### Passo 1: Preparar Conta Apple

1. Acesse [App Store Connect](https://appstoreconnect.apple.com)
2. Crie um novo app
3. Preencha informações:
   - Nome: Jennifer Félix Manicure
   - Bundle ID: com.jenniferfelixmanicure.app
   - SKU: jfm-admin-app

### Passo 2: Upload do IPA

1. Vá para "TestFlight" para testes
2. Ou direto para "App Store" para produção
3. Faça upload do arquivo `.ipa`
4. Preencha informações de versão

### Passo 3: Informações da Loja

- **Título**: Jennifer Félix Manicure
- **Subtitle**: Painel Administrativo
- **Descrição**: Gerencie seus agendamentos de manicure em tempo real. Receba notificações push de novos agendamentos, confirme ou cancele serviços.
- **Palavras-chave**: manicure, agendamento, admin, salão
- **Categoria**: Lifestyle

## 🔐 Segurança

### Antes de Publicar

1. **Remover dados sensíveis**
   ```bash
   # Verificar se há credenciais no código
   grep -r "Neoqeav2020" src/
   ```

2. **Atualizar URL da API**
   - Mudar para URL de produção em `src/services/api.ts`

3. **Configurar variáveis de ambiente**
   ```bash
   # Criar arquivo .env
   REACT_APP_API_URL=https://seu-dominio.com
   REACT_APP_ENVIRONMENT=production
   ```

4. **Testar build de produção**
   ```bash
   expo build:android -t apk --release-channel production
   ```

## 📊 Monitoramento Pós-Publicação

### Google Play Console

- Acesse Analytics para ver downloads e crashes
- Configure alertas para erros críticos
- Monitore avaliações e comentários

### App Store Connect

- Acesse Sales and Trends
- Monitore crashes em TestFlight
- Revise avaliações de usuários

## 🔄 Atualizações

### Versão Menor (Patch)

```bash
# Atualizar versão em app.json
# 1.0.0 → 1.0.1

expo publish --release-channel production
```

### Versão Maior

```bash
# Atualizar versão em app.json
# 1.0.0 → 1.1.0

# Fazer novo build
expo build:android -t app-bundle
expo build:ios -t archive
```

## 🐛 Troubleshooting

### Build falha

```bash
# Limpar cache
expo build:clean

# Tentar novamente
expo build:android -t app-bundle
```

### App não conecta à API

- Verificar URL em `src/services/api.ts`
- Verificar certificado SSL
- Testar com curl: `curl https://seu-dominio.com`

### Notificações não funcionam

- Verificar permissões no app.json
- Testar em dispositivo real
- Verificar token push em console

## 📞 Suporte

Para suporte com publicação:
- [Expo Docs](https://docs.expo.dev)
- [Google Play Help](https://support.google.com/googleplay)
- [App Store Help](https://help.apple.com/app-store-connect)

## ✅ Checklist de Publicação

- [ ] Versão atualizada em app.json
- [ ] Descrição e ícone do app prontos
- [ ] Certificados e assinaturas configurados
- [ ] URL da API atualizada
- [ ] Testado em dispositivo real
- [ ] Notificações push funcionando
- [ ] Sem dados sensíveis no código
- [ ] Build de produção gerado
- [ ] Informações da loja preenchidas
- [ ] Publicado em Google Play
- [ ] Publicado em App Store
- [ ] Monitoramento ativado
