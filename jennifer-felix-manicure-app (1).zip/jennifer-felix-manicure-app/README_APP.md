# Jennifer Félix Manicure - Aplicativo Mobile Admin

Aplicativo administrativo nativo (React Native/Expo) para gerenciar agendamentos de manicure em tempo real, com notificações push e integração completa com a página web de agendamentos.

## 📱 Características Principais

**Dashboard em Tempo Real**
- Visualize todos os agendamentos da profissional
- Filtros por data e status (Pendente, Confirmado, Cancelado)
- Atualização automática ao fazer ações
- Interface responsiva para iOS e Android

**Gerenciamento de Agendamentos**
- Confirmar agendamentos
- Cancelar agendamentos
- Deletar agendamentos
- Visualizar detalhes completos (cliente, telefone, serviço, observações)

**Notificações Push**
- Receba alertas em tempo real de novos agendamentos
- Notificações mesmo com app em background
- Configuração automática no primeiro acesso

**Autenticação Segura**
- Login com email e senha
- Tokens armazenados localmente
- Logout seguro
- Persistência de sessão

**Perfil do Usuário**
- Visualize informações da conta
- Informações sobre o app
- Funcionalidades disponíveis
- Logout rápido

## 🚀 Começar

### Pré-requisitos
- Node.js 16+
- npm ou yarn
- Expo CLI: `npm install -g expo-cli`

### Instalação

```bash
# Clonar ou acessar o diretório
cd /home/ubuntu/jennifer-felix-manicure-app

# Instalar dependências
npm install

# Iniciar o servidor Expo
npm start
```

### Executar

```bash
# Web (navegador)
npm run web
# Ou pressione 'w' no terminal Expo

# Android
npm run android
# Ou pressione 'a' no terminal Expo

# iOS
npm run ios
# Ou pressione 'i' no terminal Expo
```

## 🔐 Credenciais de Acesso

```
Email: boladosakua93@gmail.com
Senha: Neoqeav2020!
```

## 📁 Estrutura do Projeto

```
src/
├── screens/
│   ├── LoginScreen.tsx       # Tela de autenticação
│   ├── DashboardScreen.tsx   # Dashboard com agendamentos
│   └── ProfileScreen.tsx     # Perfil do usuário
├── context/
│   └── AuthContext.tsx       # Gerenciamento de autenticação
├── services/
│   ├── api.ts                # Chamadas à API backend
│   └── notifications.ts      # Configuração de notificações push
├── config/
│   └── env.ts                # Variáveis de ambiente
└── utils/
    └── helpers.ts            # Funções auxiliares

App.tsx                        # Componente principal
package.json                   # Dependências do projeto
```

## 🔌 Integração com Backend

O app se conecta à API backend em:
```
https://3000-iiuwhkeus1aqu47euup1f-38bb7a06.us2.manus.computer
```

**Endpoints Utilizados:**
- `GET /api/trpc/appointments.list` - Listar agendamentos
- `POST /api/trpc/appointments.updateStatus` - Atualizar status
- `POST /api/trpc/appointments.delete` - Deletar agendamento

## 🎨 Design

**Paleta de Cores:**
- Rosa Principal: #ec4899
- Nude/Bege: #faf5f0
- Branco: #ffffff
- Cinza: #6b7280

**Tipografia:**
- Fonte: Sistema padrão do dispositivo
- Tamanhos: 12px (pequeno) a 24px (grande)

## 🔔 Notificações Push

O app usa **Expo Notifications** para receber alertas em tempo real:

1. Ao iniciar, o app solicita permissão para notificações
2. Um token push é gerado automaticamente
3. Notificações aparecem mesmo com app em background
4. Toque na notificação para abrir o app

**Nota:** Notificações push funcionam apenas em dispositivos reais, não em emuladores.

## 📚 Documentação Adicional

- **DEPLOYMENT.md** - Guia completo para publicar em Google Play e App Store
- **TESTING.md** - Guia de testes e troubleshooting
- **app.json** - Configurações do Expo

## 🛠️ Desenvolvimento

### Adicionar Nova Tela

1. Criar arquivo em `src/screens/NovaTelaScreen.tsx`
2. Importar em `App.tsx`
3. Adicionar rota ao Tab Navigator

### Adicionar Novo Serviço

1. Criar arquivo em `src/services/novoServico.ts`
2. Exportar funções
3. Importar e usar em componentes

### Modificar Cores

Edite `src/config/env.ts` ou atualize as cores nos arquivos de estilo.

## 🐛 Troubleshooting

**App não conecta à API**
- Verifique se o backend está rodando
- Verifique a URL em `src/config/env.ts`
- Verifique a conexão de rede

**Notificações não funcionam**
- Verifique permissões no dispositivo
- Use um dispositivo real (não emulador)
- Reinicie o app

**Erro de autenticação**
- Verifique as credenciais
- Limpe o AsyncStorage: Delete e reinstale o app

**Build falha**
```bash
# Limpar cache
rm -rf node_modules package-lock.json
npm install

# Tentar novamente
npm start
```

## 📊 Dependências Principais

| Pacote | Versão | Propósito |
|--------|--------|----------|
| expo | ~54.0.33 | Framework React Native |
| react-native | 0.81.5 | Framework nativo |
| @react-navigation/native | ^7.1.8 | Navegação |
| @react-navigation/bottom-tabs | ^7.4.0 | Abas inferiores |
| expo-notifications | ~0.28.15 | Notificações push |
| axios | ^1.6.2 | Cliente HTTP |
| @react-native-async-storage/async-storage | ^1.23.1 | Armazenamento local |

## 🚀 Próximos Passos

1. **Testar Localmente** - Siga o guia em TESTING.md
2. **Publicar** - Siga o guia em DEPLOYMENT.md
3. **Monitorar** - Acompanhe crashes e feedback de usuários

## 📞 Suporte

Para suporte:
- [Expo Docs](https://docs.expo.dev)
- [React Native Docs](https://reactnative.dev)
- [Documentação do Projeto](./DEPLOYMENT.md)

## 📄 Licença

Todos os direitos reservados © 2026 Jennifer Félix Manicure

---

**Versão:** 1.0.0  
**Última Atualização:** Abril 2026  
**Desenvolvido com:** React Native, Expo, TypeScript
