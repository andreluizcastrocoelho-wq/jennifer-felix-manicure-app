# Guia de Testes - Jennifer Félix Manicure App

## 🚀 Executar Localmente

### 1. Instalar Dependências
```bash
cd /home/ubuntu/jennifer-felix-manicure-app
npm install
```

### 2. Iniciar o Servidor Expo
```bash
npm start
```

### 3. Testar em Diferentes Plataformas

#### Web (Navegador)
```bash
npm run web
# Ou pressione 'w' no terminal Expo
```

#### Android (Emulador ou Dispositivo)
```bash
npm run android
# Ou pressione 'a' no terminal Expo
```

#### iOS (Simulador ou Dispositivo)
```bash
npm run ios
# Ou pressione 'i' no terminal Expo
```

## 🧪 Fluxo de Testes

### Teste 1: Login
1. Abra o app
2. Verifique que o email está preenchido: `boladosakua93@gmail.com`
3. Digite a senha: `Neoqeav2020!`
4. Clique em "Entrar"
5. **Esperado**: Deve ir para o Dashboard

### Teste 2: Dashboard
1. Após login, você deve ver a tela de Agendamentos
2. Verifique se há agendamentos listados
3. **Esperado**: Lista de agendamentos ou mensagem "Nenhum agendamento encontrado"

### Teste 3: Filtros
1. Na tela de Dashboard, clique nos botões de filtro
2. Teste: "Todos", "Pendente", "Confirmado", "Cancelado"
3. **Esperado**: Lista deve atualizar com base no filtro

### Teste 4: Ações em Agendamento
1. Clique em "Confirmar" em um agendamento pendente
2. **Esperado**: Status deve mudar para "confirmado"
3. Clique em "Cancelar"
4. **Esperado**: Status deve mudar para "cancelado"
5. Clique em "Deletar"
6. **Esperado**: Agendamento deve ser removido da lista

### Teste 5: Perfil
1. Clique na aba "Perfil"
2. Verifique informações do usuário
3. Clique em "Sair da Aplicação"
4. **Esperado**: Deve voltar para tela de login

### Teste 6: Logout
1. Após fazer logout, tente acessar sem fazer login novamente
2. **Esperado**: Deve estar na tela de login

## 🔔 Testes de Notificações (Requer Dispositivo Real)

1. Instale o app em um dispositivo iOS ou Android
2. Abra o app e faça login
3. Acesse a página web: https://3000-iiuwhkeus1aqu47euup1f-38bb7a06.us2.manus.computer
4. Crie um novo agendamento
5. **Esperado**: Você deve receber uma notificação push no app

## 🐛 Troubleshooting

### App não conecta à API
- Verifique se o backend está rodando
- Verifique a URL em `src/config/env.ts`
- Verifique se há conexão de rede

### Notificações não funcionam
- Verifique permissões no dispositivo
- Certifique-se de estar em um dispositivo real (não emulador)
- Reinicie o app

### Erro de autenticação
- Verifique as credenciais: `boladosakua93@gmail.com` / `Neoqeav2020!`
- Limpe o AsyncStorage: Delete o app e reinstale

## 📊 Checklist de Testes

- [ ] Login funciona
- [ ] Dashboard carrega agendamentos
- [ ] Filtros funcionam
- [ ] Ações (confirmar/cancelar/deletar) funcionam
- [ ] Perfil exibe informações corretas
- [ ] Logout funciona
- [ ] Notificações push funcionam (dispositivo real)
- [ ] App é responsivo em diferentes tamanhos
- [ ] Sem erros no console

## 🚢 Após Testes Bem-Sucedidos

Quando todos os testes passarem:
1. Siga o guia em `DEPLOYMENT.md` para publicar
2. Teste em Google Play e App Store
3. Monitore crashes e feedback de usuários
