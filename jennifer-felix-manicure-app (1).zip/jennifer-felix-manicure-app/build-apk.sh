#!/bin/bash

echo "🔨 Iniciando build do APK..."
echo "Instalando EAS CLI..."

npm install -g eas-cli 2>&1 | tail -5

echo ""
echo "✅ EAS CLI instalado"
echo ""
echo "📝 Para gerar o APK, execute:"
echo ""
echo "cd /home/ubuntu/jennifer-felix-manicure-app"
echo "eas build --platform android --local"
echo ""
echo "Ou para build em nuvem (recomendado):"
echo "eas build --platform android"
echo ""
echo "Nota: Você precisa de uma conta Expo (https://expo.dev)"
